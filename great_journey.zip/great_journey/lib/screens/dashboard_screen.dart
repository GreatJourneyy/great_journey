import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/subject.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/clay_button.dart';
import '../widgets/clay_card.dart';
import '../widgets/progress_ring.dart';
import 'subject_panel_screen.dart';
import 'subject_selection_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 5) return 'Still up studying?';
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    if (hour < 22) return 'Good evening';
    return 'Working late tonight';
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final nearest = appState.nearestPaper;
    final nearestSubject = nearest == null
        ? null
        : appState.subjectOfPaper(nearest);

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppTheme.backgroundGradient,
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _greeting(),
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                        Text(
                          'GreatJourney',
                          style: Theme.of(
                            context,
                          ).textTheme.displayLarge?.copyWith(fontSize: 30),
                        ),
                      ],
                    ),
                  ),
                  ClayIconButton(
                    icon: Icons.tune,
                    size: 44,
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) =>
                            const SubjectSelectionScreen(isEditing: true),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              ClayCard(
                child: Row(
                  children: [
                    ProgressRing(
                      progress: appState.overallCompletion,
                      size: 76,
                      strokeWidth: 9,
                      centerLabel:
                          '${(appState.overallCompletion * 100).round()}%',
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Overall progress',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${appState.doneObjectivesAll} of ${appState.totalObjectivesAll} objectives done',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              const Icon(
                                Icons.local_fire_department,
                                size: 18,
                                color: AppColors.glazeClay,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                appState.streak == 0
                                    ? 'No streak yet'
                                    : '${appState.streak}-day streak',
                                style: Theme.of(context).textTheme.bodyMedium
                                    ?.copyWith(fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              if (nearest != null && nearestSubject != null) ...[
                const SizedBox(height: 14),
                ClayCard(
                  color: AppColors.dustLilac,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) =>
                          SubjectPanelScreen(subject: nearestSubject),
                    ),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.flag, color: AppColors.ink),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Up next: ${nearestSubject.name} ${nearest.name}',
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                            Text(
                              nearest.daysUntilExam! <= 0
                                  ? 'Exam day is here'
                                  : '${nearest.daysUntilExam} day${nearest.daysUntilExam == 1 ? '' : 's'} to go',
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 26),
              Text(
                'Your subjects',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 14),
              for (final subject in appState.subjects) ...[
                _SubjectRow(subject: subject),
                const SizedBox(height: 14),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _SubjectRow extends StatelessWidget {
  final Subject subject;
  const _SubjectRow({required this.subject});

  @override
  Widget build(BuildContext context) {
    return ClayCard(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => SubjectPanelScreen(subject: subject)),
      ),
      child: Row(
        children: [
          ProgressRing(
            progress: subject.completionRatio,
            size: 52,
            strokeWidth: 6,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(subject.title, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  '${subject.papers.length} papers · ${subject.doneObjectives}/${subject.totalObjectives} done',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.inkFaint),
        ],
      ),
    );
  }
}
