import 'dart:math';
import 'package:flutter/widgets.dart';

/// Clips a rect into a soft, irregular "pebble" outline instead of a
/// straight rounded rectangle — this app's one deliberate non-rectangular
/// signature shape, reserved for the 1-2 hero call-to-action buttons per
/// flow so it stays special rather than everywhere.
class BlobClipper extends CustomClipper<Path> {
  const BlobClipper();

  static const List<double> _radii = [
    0.95,
    1.0,
    0.90,
    0.98,
    0.88,
    1.0,
    0.92,
    0.97,
  ];

  @override
  Path getClip(Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final rx = size.width / 2;
    final ry = size.height / 2;
    final n = _radii.length;

    final points = <Offset>[
      for (var i = 0; i < n; i++)
        Offset(
          cx + rx * _radii[i] * cos((2 * pi * i) / n),
          cy + ry * _radii[i] * sin((2 * pi * i) / n),
        ),
    ];

    final path = Path();
    final startMid = Offset(
      (points[0].dx + points[n - 1].dx) / 2,
      (points[0].dy + points[n - 1].dy) / 2,
    );
    path.moveTo(startMid.dx, startMid.dy);
    for (var i = 0; i < n; i++) {
      final p1 = points[i];
      final p2 = points[(i + 1) % n];
      final mid = Offset((p1.dx + p2.dx) / 2, (p1.dy + p2.dy) / 2);
      path.quadraticBezierTo(p1.dx, p1.dy, mid.dx, mid.dy);
    }
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}
