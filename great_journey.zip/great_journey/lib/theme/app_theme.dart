import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// GreatJourney design tokens.
///
/// Aesthetic: "glazed ceramic" — soft, rounded, dual-shadow (claymorphism)
/// surfaces in a light blue / grey palette. Every button and card is built
/// from the same raised/pressed surface language defined here, so the whole
/// app reads as one continuous material rather than a stack of screens.
class AppColors {
  AppColors._();

  // Background wash — pale sky fading into cool stone.
  static const Color bgTop = Color(0xFFF3F7FA);
  static const Color bgBottom = Color(0xFFDEE7EE);

  // Core ceramic identity.
  static const Color glazeBlue = Color(0xFFA2C9E3);
  static const Color glazeBlueDeep = Color(0xFF5D8FB8);
  static const Color stoneGray = Color(0xFFCFD7DD);
  static const Color stoneGrayDeep = Color(0xFFAAB6BF);

  // Text.
  static const Color ink = Color(0xFF37454F);
  static const Color inkFaint = Color(0xFF76838D);

  // Functional state accents — kept inside the same pastel-glaze family.
  static const Color glazeSage = Color(0xFFA3CDB4); // done / on-track
  static const Color dustLilac = Color(0xFFC3B7DA); // deferred / tomorrow
  static const Color glazeClay = Color(0xFFE3B896); // behind / needs focus

  // Pure highlight used for the glossy "sheen" signature element.
  static const Color sheen = Color(0xFFFFFFFF);
}

class AppRadii {
  AppRadii._();
  static const double pill = 999;
  static const double card = 28;
  static const double cardSmall = 20;
  static const double blob = 40;
}

class AppTheme {
  AppTheme._();

  static TextTheme get _textTheme {
    final base = GoogleFonts.manropeTextTheme();
    final display = GoogleFonts.frauncesTextTheme();
    return base.copyWith(
      displayLarge: display.displayLarge?.copyWith(
        fontWeight: FontWeight.w600,
        fontStyle: FontStyle.italic,
        color: AppColors.ink,
        letterSpacing: -0.5,
      ),
      headlineLarge: display.headlineLarge?.copyWith(
        fontWeight: FontWeight.w600,
        color: AppColors.ink,
        fontSize: 30,
      ),
      headlineMedium: display.headlineMedium?.copyWith(
        fontWeight: FontWeight.w600,
        color: AppColors.ink,
        fontSize: 24,
      ),
      headlineSmall: display.headlineSmall?.copyWith(
        fontWeight: FontWeight.w600,
        color: AppColors.ink,
        fontSize: 19,
      ),
      titleLarge: base.titleLarge?.copyWith(
        fontWeight: FontWeight.w700,
        color: AppColors.ink,
      ),
      titleMedium: base.titleMedium?.copyWith(
        fontWeight: FontWeight.w700,
        color: AppColors.ink,
      ),
      bodyLarge: base.bodyLarge?.copyWith(color: AppColors.ink, height: 1.4),
      bodyMedium: base.bodyMedium?.copyWith(
        color: AppColors.inkFaint,
        height: 1.4,
      ),
      labelLarge: base.labelLarge?.copyWith(
        fontWeight: FontWeight.w700,
        color: AppColors.ink,
      ),
    );
  }

  static ThemeData get light {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.bgBottom,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.glazeBlueDeep,
        brightness: Brightness.light,
        primary: AppColors.glazeBlueDeep,
        secondary: AppColors.dustLilac,
        surface: AppColors.bgTop,
      ),
      textTheme: _textTheme,
      splashFactory: NoSplash.splashFactory,
      highlightColor: Colors.transparent,
    );
  }

  static const LinearGradient backgroundGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [AppColors.bgTop, AppColors.bgBottom],
  );

  /// Soft dual shadow that makes a surface look like it's rising out of
  /// the clay — light catches the top-left, a cool shadow pools bottom-right.
  static List<BoxShadow> raised({double strength = 1}) => [
    BoxShadow(
      color: AppColors.sheen.withValues(alpha: 0.9 * strength),
      offset: const Offset(-6, -6),
      blurRadius: 16,
    ),
    BoxShadow(
      color: AppColors.stoneGrayDeep.withValues(alpha: 0.55 * strength),
      offset: const Offset(7, 7),
      blurRadius: 18,
    ),
  ];

  /// Shallower version for small elements (chips, icon buttons).
  static List<BoxShadow> raisedSmall() => [
    BoxShadow(
      color: AppColors.sheen.withValues(alpha: 0.85),
      offset: const Offset(-3, -3),
      blurRadius: 8,
    ),
    BoxShadow(
      color: AppColors.stoneGrayDeep.withValues(alpha: 0.45),
      offset: const Offset(4, 4),
      blurRadius: 10,
    ),
  ];

  /// Gradient fill for a raised surface — light source top-left.
  static LinearGradient raisedFill(Color base) => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [_lighten(base, 0.16), base, _darken(base, 0.05)],
  );

  /// Gradient + shadow inversion used for the "pressed in" / selected
  /// state — simulates an inset shadow since Flutter has no native one.
  static LinearGradient pressedFill(Color base) => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [_darken(base, 0.12), base, _lighten(base, 0.10)],
  );

  static List<BoxShadow> pressed() => [
    BoxShadow(
      color: AppColors.stoneGrayDeep.withValues(alpha: 0.35),
      offset: const Offset(-2, -2),
      blurRadius: 6,
    ),
    BoxShadow(
      color: AppColors.sheen.withValues(alpha: 0.5),
      offset: const Offset(2, 2),
      blurRadius: 6,
    ),
  ];

  static Color _lighten(Color c, double amount) {
    final hsl = HSLColor.fromColor(c);
    return hsl
        .withLightness((hsl.lightness + amount).clamp(0.0, 1.0))
        .toColor();
  }

  static Color _darken(Color c, double amount) {
    final hsl = HSLColor.fromColor(c);
    return hsl
        .withLightness((hsl.lightness - amount).clamp(0.0, 1.0))
        .toColor();
  }
}
