import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'clay_button.dart';

/// An empty checklist is an invitation to act, not a dead end — this
/// widget always pairs the message with a way forward.
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 12),
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: AppTheme.raisedFill(AppColors.bgTop),
              boxShadow: AppTheme.raised(),
            ),
            child: Icon(icon, color: AppColors.glazeBlueDeep, size: 26),
          ),
          const SizedBox(height: 16),
          Text(
            title,
            style: Theme.of(context).textTheme.titleMedium,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 6),
          Text(
            message,
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
          if (actionLabel != null && onAction != null) ...[
            const SizedBox(height: 18),
            ClayButton(
              label: actionLabel!,
              icon: Icons.add_rounded,
              onPressed: onAction,
              compact: true,
            ),
          ],
        ],
      ),
    );
  }
}
