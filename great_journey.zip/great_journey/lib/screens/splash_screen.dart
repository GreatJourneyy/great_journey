import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/clay_button.dart';
import 'subject_selection_screen.dart';
import 'dashboard_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  bool _navigated = false;
  bool _scheduledAutoNav = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _goNext(BuildContext context, {required bool onboarded}) {
    if (_navigated) return;
    _navigated = true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => onboarded
            ? const DashboardScreen()
            : const SubjectSelectionScreen(),
      ),
    );
  }

  Animation<double> _fade(double start, double end) => CurvedAnimation(
    parent: _controller,
    curve: Interval(start, end, curve: Curves.easeOut),
  );

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();

    if (!appState.loading && appState.hasOnboarded && !_scheduledAutoNav) {
      _scheduledAutoNav = true;
      Future.delayed(const Duration(milliseconds: 900), () {
        if (mounted) _goNext(context, onboarded: true);
      });
    }

    final iconFade = _fade(0.0, 0.45);
    final titleFade = _fade(0.25, 0.65);
    final taglineFade = _fade(0.4, 0.75);
    final buttonFade = _fade(0.6, 1.0);

    Widget bottomContent;
    if (appState.loading || appState.hasOnboarded) {
      bottomContent = const SizedBox(
        width: 22,
        height: 22,
        child: CircularProgressIndicator(
          strokeWidth: 2.4,
          color: AppColors.glazeBlueDeep,
        ),
      );
    } else {
      bottomContent = ClayBlobButton(
        label: 'Begin Your Journey',
        icon: Icons.arrow_forward_rounded,
        onPressed: () => _goNext(context, onboarded: false),
      );
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppTheme.backgroundGradient,
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(flex: 3),
                FadeTransition(
                  opacity: iconFade,
                  child: ScaleTransition(
                    scale: Tween(begin: 0.85, end: 1.0).animate(iconFade),
                    child: Container(
                      width: 132,
                      height: 132,
                      padding: const EdgeInsets.all(9),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppTheme.raisedFill(AppColors.bgTop),
                        boxShadow: AppTheme.raised(strength: 1.2),
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/app_icon.jpg',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                FadeTransition(
                  opacity: titleFade,
                  child: SlideTransition(
                    position:
                        Tween(
                          begin: const Offset(0, 0.15),
                          end: Offset.zero,
                        ).animate(titleFade),
                    child: Text(
                      'GreatJourney',
                      style: Theme.of(
                        context,
                      ).textTheme.displayLarge?.copyWith(fontSize: 38),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                FadeTransition(
                  opacity: taglineFade,
                  child: Text(
                    'One paper at a time.',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: AppColors.inkFaint,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Spacer(flex: 3),
                FadeTransition(
                  opacity: buttonFade,
                  child: SlideTransition(
                    position:
                        Tween(
                          begin: const Offset(0, 0.2),
                          end: Offset.zero,
                        ).animate(buttonFade),
                    child: bottomContent,
                  ),
                ),
                const SizedBox(height: 22),
                FadeTransition(
                  opacity: buttonFade,
                  child: Text(
                    'Made by OldArad',
                    style: GoogleFonts.cormorantGaramond(
                      fontSize: 15,
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.2,
                      color: AppColors.inkFaint,
                    ),
                  ),
                ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
