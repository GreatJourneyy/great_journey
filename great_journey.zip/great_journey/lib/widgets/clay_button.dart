import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import 'blob_clipper.dart';

/// Soft glossy highlight painted in the top-left of a raised surface —
/// the shared detail that ties every clay surface in the app together.
class _Sheen extends StatelessWidget {
  final BorderRadius? radius;
  const _Sheen({this.radius});

  @override
  Widget build(BuildContext context) {
    final overlay = DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: radius,
        gradient: LinearGradient(
          begin: const Alignment(-0.9, -0.9),
          end: const Alignment(0.25, 0.2),
          colors: [
            AppColors.sheen.withValues(alpha: 0.45),
            AppColors.sheen.withValues(alpha: 0.0),
          ],
          stops: const [0.0, 0.75],
        ),
      ),
    );
    return IgnorePointer(child: overlay);
  }
}

/// Primary pill-shaped action button in the ceramic clay language.
/// Presses inward (inset shadow) instead of the usual Material ripple.
class ClayButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final Color color;
  final Color? textColor;
  final bool fullWidth;
  final bool compact;

  const ClayButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.color = AppColors.glazeBlue,
    this.textColor,
    this.fullWidth = false,
    this.compact = false,
  });

  @override
  State<ClayButton> createState() => _ClayButtonState();
}

class _ClayButtonState extends State<ClayButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final disabled = widget.onPressed == null;
    final fg = widget.textColor ?? AppColors.ink;
    final radius = BorderRadius.circular(AppRadii.pill);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTapDown: disabled
            ? null
            : (_) {
                setState(() => _pressed = true);
                HapticFeedback.lightImpact();
              },
        onTapUp: disabled
            ? null
            : (_) {
                setState(() => _pressed = false);
                widget.onPressed?.call();
              },
        onTapCancel: disabled ? null : () => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? 0.96 : 1,
          duration: const Duration(milliseconds: 110),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 140),
            width: widget.fullWidth ? double.infinity : null,
            padding: EdgeInsets.symmetric(
              horizontal: widget.compact ? 18 : 28,
              vertical: widget.compact ? 11 : 16,
            ),
            decoration: BoxDecoration(
              borderRadius: radius,
              gradient: _pressed
                  ? AppTheme.pressedFill(widget.color)
                  : AppTheme.raisedFill(widget.color),
              boxShadow: _pressed
                  ? AppTheme.pressed()
                  : AppTheme.raisedSmall(),
            ),
            child: Stack(
              children: [
                if (!_pressed) _Sheen(radius: radius),
                Row(
                  mainAxisSize: widget.fullWidth
                      ? MainAxisSize.max
                      : MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (widget.icon != null) ...[
                      Icon(widget.icon, size: 18, color: fg),
                      const SizedBox(width: 8),
                    ],
                    Text(
                      widget.label,
                      style: Theme.of(
                        context,
                      ).textTheme.labelLarge?.copyWith(color: fg),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Small circular button for one-glyph actions (defer, delete, edit, add).
class ClayIconButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback? onPressed;
  final Color color;
  final Color iconColor;
  final double size;

  const ClayIconButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.color = AppColors.bgTop,
    this.iconColor = AppColors.ink,
    this.size = 42,
  });

  @override
  State<ClayIconButton> createState() => _ClayIconButtonState();
}

class _ClayIconButtonState extends State<ClayIconButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final disabled = widget.onPressed == null;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTapDown: disabled
            ? null
            : (_) {
                setState(() => _pressed = true);
                HapticFeedback.selectionClick();
              },
        onTapUp: disabled
            ? null
            : (_) {
                setState(() => _pressed = false);
                widget.onPressed?.call();
              },
        onTapCancel: disabled ? null : () => setState(() => _pressed = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: _pressed
                ? AppTheme.pressedFill(widget.color)
                : AppTheme.raisedFill(widget.color),
            boxShadow: _pressed ? AppTheme.pressed() : AppTheme.raisedSmall(),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              if (!_pressed)
                ClipOval(child: _Sheen(radius: BorderRadius.circular(999))),
              Icon(widget.icon, size: widget.size * 0.45, color: widget.iconColor),
            ],
          ),
        ),
      ),
    );
  }
}

/// Hero call-to-action with the app's organic "pebble" outline. Reserve
/// this for the one or two most important actions per screen so it stays
/// a signature moment rather than the default button shape everywhere.
class ClayBlobButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final Color color;

  const ClayBlobButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.color = AppColors.glazeBlueDeep,
  });

  @override
  State<ClayBlobButton> createState() => _ClayBlobButtonState();
}

class _ClayBlobButtonState extends State<ClayBlobButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final disabled = widget.onPressed == null;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTapDown: disabled
            ? null
            : (_) {
                setState(() => _pressed = true);
                HapticFeedback.mediumImpact();
              },
        onTapUp: disabled
            ? null
            : (_) {
                setState(() => _pressed = false);
                widget.onPressed?.call();
              },
        onTapCancel: disabled ? null : () => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? 0.95 : 1,
          duration: const Duration(milliseconds: 120),
          child: ClipPath(
            clipper: const BlobClipper(),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 140),
              padding: const EdgeInsets.symmetric(
                horizontal: 40,
                vertical: 22,
              ),
              decoration: BoxDecoration(
                gradient: _pressed
                    ? AppTheme.pressedFill(widget.color)
                    : AppTheme.raisedFill(widget.color),
              ),
              child: Stack(
                children: [
                  if (!_pressed) const _Sheen(),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (widget.icon != null) ...[
                        Icon(widget.icon, color: AppColors.bgTop, size: 20),
                        const SizedBox(width: 10),
                      ],
                      Text(
                        widget.label,
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(
                              color: AppColors.bgTop,
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
