# GreatJourney

A study checklist app for Business 9609, Computer Science 9618, and Math
Edexcel — ceramic/claymorphism design, built in Flutter.

## ⚠️ Before you do anything else: HarmonyOS

Flutter does not officially target HarmonyOS. What actually happens depends
on which version your tablet runs:

- **HarmonyOS 4 or earlier** (the AOSP-based versions): these can install
  and run a normal Android `.apk` — this build should just work.
- **HarmonyOS NEXT / HarmonyOS 5** (fully rebuilt, dropped Android app
  support entirely): a Flutter-built `.apk` will **not** install directly.
  Your options are (1) an Android-app-in-a-box tool such as DroiTong or
  Easy Abroad if your tablet has one, or (2) sideload and test primarily on
  the Samsung device, since that will always work regardless.

Check **Settings → About tablet** on the Harmony device to see which you
have before you spend time on it.

## Setup

You'll need the Flutter SDK installed (`flutter --version` to check).

```bash
cd great_journey
flutter create .          # generates the missing android/ platform folder —
                           # safe, this will not touch lib/ or pubspec.yaml
flutter pub get           # fetches google_fonts, provider, shared_preferences
dart run flutter_launcher_icons   # turns your mask photo into the real home-screen icon
flutter run                # or open the folder in Android Studio / VS Code and hit Run
```

For the Samsung device, plug it in with USB debugging on and `flutter run`
will find it. For a release build to actually distribute:
`flutter build apk --release` → output lands in
`build/app/outputs/flutter-apk/app-release.apk`.

## Project structure

```
lib/
  main.dart                    entry point, theme + provider wiring
  theme/app_theme.dart         colors, type, the raised/pressed clay system
  models/                      Objective, Paper, Subject (+ JSON serialization)
  data/syllabus_data.dart      the 3 preset subjects and their papers
  services/storage_service.dart  local persistence (shared_preferences)
  providers/app_state.dart     all app logic lives here
  widgets/                     reusable clay buttons, cards, checkbox, ring, dialogs
  screens/                     splash → subject selection → dashboard → subject → paper
```

## How the mechanics work

- **Push to tomorrow**: an objective moves out of Today into a "Deferred"
  bucket dated tomorrow. Next time you open the app on/after that date, it
  automatically rolls back into Today on its own.
- **Set as Default**: snapshots your current checklist for that paper.
  **Reset to Default** later restores a fresh, all-unchecked copy of that
  exact list — handy for repeating the same routine weekly. **Clear
  Default** removes the saved snapshot.
- **Pace**: remaining objectives ÷ days left = a rough daily target, shown
  as a status line on each paper.
- Swipe an objective left to delete it (Undo appears in a snackbar).
  Long-press an objective to rename it.

Everything is stored locally on-device (`shared_preferences`) — nothing is
sent anywhere.
