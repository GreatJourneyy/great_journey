import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';

/// General-purpose raised ceramic surface used for content containers.
/// Pass [onTap] to make it a soft-pressable navigation card.
class ClayCard extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final EdgeInsetsGeometry padding;
  final double radius;

  const ClayCard({
    super.key,
    required this.child,
    this.onTap,
    this.color = AppColors.bgTop,
    this.padding = const EdgeInsets.all(20),
    this.radius = AppRadii.card,
  });

  @override
  State<ClayCard> createState() => _ClayCardState();
}

class _ClayCardState extends State<ClayCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final interactive = widget.onTap != null;
    final radius = BorderRadius.circular(widget.radius);

    final surface = AnimatedContainer(
      duration: const Duration(milliseconds: 140),
      padding: widget.padding,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: radius,
        gradient: _pressed
            ? AppTheme.pressedFill(widget.color)
            : AppTheme.raisedFill(widget.color),
        boxShadow: _pressed ? AppTheme.pressed() : AppTheme.raised(),
      ),
      child: widget.child,
    );

    if (!interactive) return surface;

    return GestureDetector(
      onTapDown: (_) {
        setState(() => _pressed = true);
        HapticFeedback.selectionClick();
      },
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap?.call();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.985 : 1,
        duration: const Duration(milliseconds: 120),
        child: surface,
      ),
    );
  }
}

/// A card that toggles between raised (unselected) and pressed-in
/// (selected) states — used for the subject multi-select screen.
class ClayToggleCard extends StatelessWidget {
  final Widget child;
  final bool selected;
  final VoidCallback onTap;
  final Color color;

  const ClayToggleCard({
    super.key,
    required this.child,
    required this.selected,
    required this.onTap,
    this.color = AppColors.glazeBlue,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        curve: Curves.easeOut,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppRadii.card),
          gradient: selected
              ? AppTheme.pressedFill(color)
              : AppTheme.raisedFill(AppColors.bgTop),
          boxShadow: selected ? AppTheme.pressed() : AppTheme.raised(),
          border: selected
              ? Border.all(color: AppColors.glazeBlueDeep, width: 1.4)
              : null,
        ),
        child: Row(
          children: [
            Expanded(child: child),
            const SizedBox(width: 12),
            AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected ? AppColors.glazeSage : Colors.transparent,
                border: Border.all(
                  color: selected ? AppColors.glazeSage : AppColors.stoneGrayDeep,
                  width: 1.6,
                ),
              ),
              child: selected
                  ? const Icon(Icons.check, size: 16, color: Colors.white)
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}
