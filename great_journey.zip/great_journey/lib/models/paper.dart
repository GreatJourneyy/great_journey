import 'objective.dart';

class Paper {
  final String id;
  String name;
  DateTime? examDate;
  List<Objective> objectives;

  /// Saved snapshot used by "Set as Default" / "Reset to Default".
  List<Objective>? defaultSnapshot;
  final bool isCustom;

  Paper({
    required this.id,
    required this.name,
    this.examDate,
    List<Objective>? objectives,
    this.defaultSnapshot,
    this.isCustom = false,
  }) : objectives = objectives ?? [];

  // ---- Derived lists ----------------------------------------------------

  List<Objective> get todayObjectives =>
      objectives.where((o) => !o.isDone && !o.isDeferred).toList();

  List<Objective> get deferredObjectives =>
      objectives.where((o) => !o.isDone && o.isDeferred).toList();

  List<Objective> get doneObjectives =>
      objectives.where((o) => o.isDone).toList();

  int get totalCount => objectives.length;
  int get doneCount => doneObjectives.length;
  int get remainingCount => totalCount - doneCount;

  double get completionRatio =>
      totalCount == 0 ? 0 : doneCount / totalCount;

  // ---- Countdown & pace ---------------------------------------------------

  int? get daysUntilExam {
    if (examDate == null) return null;
    final diff = dateOnly(examDate!).difference(dateOnly(DateTime.now()));
    return diff.inDays;
  }

  /// Objectives-per-day needed to finish everything before the exam.
  /// Null when there's nothing left, or no exam date set.
  double? get pacePerDay {
    final days = daysUntilExam;
    if (days == null || remainingCount == 0) return null;
    final effectiveDays = days <= 0 ? 1 : days;
    return remainingCount / effectiveDays;
  }

  /// Moves any objective whose defer date has arrived back into Today.
  /// Returns true if anything changed (so callers can persist/refresh).
  bool rollDueObjectives() {
    var changed = false;
    for (final o in objectives) {
      if (o.rollIfDue(DateTime.now())) changed = true;
    }
    return changed;
  }

  void setAsDefault() {
    defaultSnapshot = objectives.map((o) => o.copy()).toList();
  }

  bool get hasDefault => defaultSnapshot != null && defaultSnapshot!.isNotEmpty;

  /// Restores a fresh, all-unchecked copy of the saved default checklist.
  void resetToDefault() {
    if (defaultSnapshot == null) return;
    objectives = defaultSnapshot!
        .map(
          (o) => Objective(
            id: '${o.id}_${DateTime.now().microsecondsSinceEpoch}',
            text: o.text,
            isDone: false,
          ),
        )
        .toList();
  }

  void clearDefault() => defaultSnapshot = null;

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'examDate': examDate?.toIso8601String(),
    'objectives': objectives.map((o) => o.toJson()).toList(),
    'defaultSnapshot': defaultSnapshot?.map((o) => o.toJson()).toList(),
    'isCustom': isCustom,
  };

  factory Paper.fromJson(Map<String, dynamic> json) => Paper(
    id: json['id'] as String,
    name: json['name'] as String,
    examDate: json['examDate'] == null
        ? null
        : DateTime.parse(json['examDate'] as String),
    objectives: (json['objectives'] as List<dynamic>? ?? [])
        .map((e) => Objective.fromJson(e as Map<String, dynamic>))
        .toList(),
    defaultSnapshot: (json['defaultSnapshot'] as List<dynamic>?)
        ?.map((e) => Objective.fromJson(e as Map<String, dynamic>))
        .toList(),
    isCustom: json['isCustom'] as bool? ?? false,
  );
}
