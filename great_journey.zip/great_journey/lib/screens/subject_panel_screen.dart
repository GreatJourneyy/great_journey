import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/paper.dart';
import '../models/subject.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/clay_button.dart';
import '../widgets/clay_card.dart';
import '../widgets/clay_dialog.dart';
import '../widgets/progress_ring.dart';
import 'paper_panel_screen.dart';

class SubjectPanelScreen extends StatelessWidget {
  final Subject subject;
  const SubjectPanelScreen({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    // Re-fetch in case the subject list changed underneath us.
    final live = appState.subjects.firstWhere(
      (s) => s.id == subject.id,
      orElse: () => subject,
    );

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppTheme.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
                child: Row(
                  children: [
                    ClayIconButton(
                      icon: Icons.arrow_back_rounded,
                      size: 40,
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            live.title,
                            style: Theme.of(context).textTheme.headlineMedium,
                          ),
                          Text(
                            '${live.doneObjectives}/${live.totalObjectives} objectives done',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                  children: [
                    for (final paper in live.papers) ...[
                      _PaperRow(subject: live, paper: paper),
                      const SizedBox(height: 14),
                    ],
                    ClayCard(
                      color: AppColors.bgBottom,
                      onTap: () async {
                        final name = await promptText(
                          context,
                          title: 'Paper name',
                          hint: 'e.g. P52 or Unit 3',
                        );
                        if (name != null && name.trim().isNotEmpty) {
                          appState.addCustomPaper(live, name.trim());
                        }
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.add_rounded,
                            color: AppColors.glazeBlueDeep,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'Add a paper',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PaperRow extends StatelessWidget {
  final Subject subject;
  final Paper paper;
  const _PaperRow({required this.subject, required this.paper});

  @override
  Widget build(BuildContext context) {
    final appState = context.read<AppState>();
    final days = paper.daysUntilExam;

    return ClayCard(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => PaperPanelScreen(subject: subject, paper: paper),
        ),
      ),
      child: Row(
        children: [
          ProgressRing(progress: paper.completionRatio, size: 50, strokeWidth: 6),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(paper.name, style: Theme.of(context).textTheme.titleMedium),
                    if (paper.isCustom) ...[
                      const SizedBox(width: 6),
                      const Icon(Icons.auto_awesome, size: 14, color: AppColors.glazeBlueDeep),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  days == null
                      ? '${paper.totalCount} objectives · no date set'
                      : days <= 0
                          ? 'Exam day is here'
                          : '$days day${days == 1 ? '' : 's'} to go · ${paper.remainingCount} left',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          if (paper.isCustom)
            ClayIconButton(
              icon: Icons.delete_outline,
              size: 34,
              onPressed: () async {
                final confirmed = await confirmAction(
                  context,
                  title: 'Remove ${paper.name}?',
                  message: "Its checklist goes with it — that part can't be undone.",
                  confirmLabel: 'Remove',
                );
                if (confirmed) appState.removePaper(subject, paper);
              },
            )
          else
            const Icon(Icons.chevron_right_rounded, color: AppColors.inkFaint),
        ],
      ),
    );
  }
}
