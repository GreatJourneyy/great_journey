import 'paper.dart';

class Subject {
  final String id;
  String name;
  String code;
  List<Paper> papers;
  final bool isCustom;

  Subject({
    required this.id,
    required this.name,
    required this.code,
    List<Paper>? papers,
    this.isCustom = false,
  }) : papers = papers ?? [];

  String get title => code.isEmpty ? name : '$name $code';

  int get totalObjectives =>
      papers.fold(0, (sum, p) => sum + p.totalCount);
  int get doneObjectives => papers.fold(0, (sum, p) => sum + p.doneCount);

  double get completionRatio =>
      totalObjectives == 0 ? 0 : doneObjectives / totalObjectives;

  /// Days until the soonest upcoming exam across this subject's papers.
  int? get nearestExamDays {
    final days = papers
        .map((p) => p.daysUntilExam)
        .whereType<int>()
        .toList();
    if (days.isEmpty) return null;
    days.sort();
    return days.first;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'code': code,
    'papers': papers.map((p) => p.toJson()).toList(),
    'isCustom': isCustom,
  };

  factory Subject.fromJson(Map<String, dynamic> json) => Subject(
    id: json['id'] as String,
    name: json['name'] as String,
    code: json['code'] as String,
    papers: (json['papers'] as List<dynamic>? ?? [])
        .map((e) => Paper.fromJson(e as Map<String, dynamic>))
        .toList(),
    isCustom: json['isCustom'] as bool? ?? false,
  );
}
