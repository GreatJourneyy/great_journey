import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Thin wrapper around shared_preferences. AppState owns the shape of the
/// data; this class just persists whatever JSON-safe map it's given, so
/// everything survives closing the app.
class StorageService {
  static const _key = 'great_journey_state_v1';

  Future<void> save(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(data));
  }

  Future<Map<String, dynamic>?> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return null;
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      // Corrupt or outdated data — start fresh rather than crash.
      return null;
    }
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
