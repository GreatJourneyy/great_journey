import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/syllabus_data.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/clay_button.dart';
import '../widgets/clay_card.dart';
import '../widgets/clay_dialog.dart';
import 'dashboard_screen.dart';

class SubjectSelectionScreen extends StatelessWidget {
  final bool isEditing;
  const SubjectSelectionScreen({super.key, this.isEditing = false});

  IconData _iconFor(String name) {
    switch (name) {
      case 'Business':
        return Icons.business_center;
      case 'Computer Science':
        return Icons.computer;
      case 'Math':
        return Icons.functions;
      default:
        return Icons.menu_book;
    }
  }

  Future<void> _toggleWithGuard(
    BuildContext context,
    AppState appState,
    SubjectTemplate t,
  ) async {
    final existing = appState.findSelected(t);
    if (existing != null && existing.totalObjectives > 0) {
      final confirmed = await confirmAction(
        context,
        title: 'Remove ${existing.title}?',
        message:
            "This clears its checklist and progress too — that part can't be undone.",
        confirmLabel: 'Remove',
      );
      if (!confirmed) return;
    }
    appState.toggleSubjectSelection(t);
  }

  Future<void> _addCustomSubject(
    BuildContext context,
    AppState appState,
  ) async {
    final name = await promptText(
      context,
      title: 'Subject name',
      hint: 'e.g. Physics',
    );
    if (name == null || name.trim().isEmpty) return;
    if (!context.mounted) return;

    final code = await promptText(
      context,
      title: 'Syllabus code (optional)',
      hint: 'e.g. 9702',
    );
    if (!context.mounted) return;

    final papersRaw = await promptText(
      context,
      title: 'Papers',
      hint: 'e.g. P1, P2, P3',
    );
    final papers = (papersRaw ?? '')
        .split(',')
        .map((p) => p.trim())
        .where((p) => p.isNotEmpty)
        .toList();
    if (papers.isEmpty) papers.add('Paper 1');

    appState.addCustomSubject(name.trim(), (code ?? '').trim(), papers);
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final hasSelection = appState.subjects.isNotEmpty;
    final customSubjects = appState.subjects.where((s) => s.isCustom).toList();

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppTheme.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.fromLTRB(24, isEditing ? 10 : 26, 24, 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (isEditing) ...[
                      ClayIconButton(
                        icon: Icons.arrow_back_rounded,
                        size: 40,
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                      const SizedBox(width: 12),
                    ],
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Choose your subjects',
                            style: Theme.of(context).textTheme.headlineMedium,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Pick everything you're preparing for — add as many as you like.",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(24, 14, 24, 12),
                  children: [
                    for (final t in appState.availableTemplates) ...[
                      ClayToggleCard(
                        selected: appState.isSelected(t),
                        onTap: () => _toggleWithGuard(context, appState, t),
                        child: Row(
                          children: [
                            Icon(_iconFor(t.name), color: AppColors.glazeBlueDeep),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    t.name,
                                    style: Theme.of(context).textTheme.titleMedium,
                                  ),
                                  Text(
                                    '${t.code} · ${t.paperNames.length} papers',
                                    style: Theme.of(context).textTheme.bodyMedium,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                    ],
                    if (customSubjects.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(
                        'Your subjects',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 10),
                      for (final s in customSubjects) ...[
                        ClayCard(
                          child: Row(
                            children: [
                              const Icon(
                                Icons.auto_awesome,
                                color: AppColors.glazeBlueDeep,
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      s.title,
                                      style: Theme.of(context).textTheme.titleMedium,
                                    ),
                                    Text(
                                      '${s.papers.length} papers',
                                      style: Theme.of(context).textTheme.bodyMedium,
                                    ),
                                  ],
                                ),
                              ),
                              ClayIconButton(
                                icon: Icons.delete_outline,
                                size: 36,
                                onPressed: () async {
                                  final confirmed = await confirmAction(
                                    context,
                                    title: 'Remove ${s.title}?',
                                    message:
                                        "This clears its checklist and progress too — that part can't be undone.",
                                    confirmLabel: 'Remove',
                                  );
                                  if (confirmed) appState.removeSubject(s);
                                },
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                      ],
                    ],
                    ClayCard(
                      onTap: () => _addCustomSubject(context, appState),
                      color: AppColors.bgBottom,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.add_rounded, color: AppColors.glazeBlueDeep),
                          const SizedBox(width: 10),
                          Text(
                            'Add a subject of your own',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 26),
                child: Center(
                  child: ClayBlobButton(
                    label: isEditing ? 'Done' : "That's all!",
                    icon: Icons.check_rounded,
                    onPressed: !hasSelection
                        ? null
                        : () {
                            appState.completeOnboarding();
                            if (isEditing) {
                              Navigator.of(context).pop();
                            } else {
                              Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                  builder: (_) => const DashboardScreen(),
                                ),
                              );
                            }
                          },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
