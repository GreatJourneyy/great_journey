import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';

/// Circular checkbox styled as a little glazed bead — hollow ceramic ring
/// when unchecked, fills with sage glaze and a checkmark when done.
class ClayCheckbox extends StatelessWidget {
  final bool value;
  final VoidCallback onChanged;
  final double size;

  const ClayCheckbox({
    super.key,
    required this.value,
    required this.onChanged,
    this.size = 30,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        onChanged();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOutBack,
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: value
              ? AppTheme.pressedFill(AppColors.glazeSage)
              : AppTheme.raisedFill(AppColors.bgTop),
          boxShadow: value ? AppTheme.pressed() : AppTheme.raisedSmall(),
          border: Border.all(
            color: value ? AppColors.glazeSage : AppColors.stoneGrayDeep,
            width: 1.4,
          ),
        ),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 180),
          child: value
              ? Icon(
                  Icons.check_rounded,
                  key: const ValueKey('checked'),
                  size: size * 0.62,
                  color: Colors.white,
                )
              : const SizedBox.shrink(key: ValueKey('unchecked')),
        ),
      ),
    );
  }
}
