import 'package:flutter/foundation.dart';
import '../data/syllabus_data.dart';
import '../models/objective.dart';
import '../models/paper.dart';
import '../models/subject.dart';
import '../services/storage_service.dart';

class AppState extends ChangeNotifier {
  final StorageService _storage = StorageService();

  List<Subject> subjects = [];
  bool hasOnboarded = false;
  int streak = 0;
  DateTime? lastActiveDate;
  bool _loading = true;
  int _idCounter = 0;

  bool get loading => _loading;
  List<SubjectTemplate> get availableTemplates => kAvailableSubjects;

  String _newId() {
    _idCounter++;
    return '${DateTime.now().microsecondsSinceEpoch}_$_idCounter';
  }

  // ---- Lifecycle ----------------------------------------------------------

  Future<void> init() async {
    final data = await _storage.load();
    if (data != null) {
      hasOnboarded = data['hasOnboarded'] as bool? ?? false;
      streak = data['streak'] as int? ?? 0;
      lastActiveDate = data['lastActiveDate'] == null
          ? null
          : DateTime.parse(data['lastActiveDate'] as String);
      subjects = (data['subjects'] as List<dynamic>? ?? [])
          .map((e) => Subject.fromJson(e as Map<String, dynamic>))
          .toList();
    }

    for (final s in subjects) {
      for (final p in s.papers) {
        p.rollDueObjectives();
      }
    }

    if (lastActiveDate != null) {
      final gap = dateOnly(
        DateTime.now(),
      ).difference(dateOnly(lastActiveDate!)).inDays;
      if (gap > 1) streak = 0;
    }

    _loading = false;
    notifyListeners();
    await _persist();
  }

  Future<void> _persist() async {
    await _storage.save({
      'hasOnboarded': hasOnboarded,
      'streak': streak,
      'lastActiveDate': lastActiveDate?.toIso8601String(),
      'subjects': subjects.map((s) => s.toJson()).toList(),
    });
  }

  void touch() {
    _persist();
    notifyListeners();
  }

  void rollDueForPaper(Paper paper) {
    if (paper.rollDueObjectives()) touch();
  }

  // ---- Onboarding / subject selection --------------------------------------

  Subject? findSelected(SubjectTemplate t) {
    for (final s in subjects) {
      if (s.name == t.name && s.code == t.code) return s;
    }
    return null;
  }

  bool isSelected(SubjectTemplate t) => findSelected(t) != null;

  void toggleSubjectSelection(SubjectTemplate t) {
    final existing = findSelected(t);
    if (existing != null) {
      subjects.removeWhere((s) => s.id == existing.id);
    } else {
      subjects.add(
        Subject(
          id: _newId(),
          name: t.name,
          code: t.code,
          papers: t.paperNames
              .map((n) => Paper(id: _newId(), name: n))
              .toList(),
        ),
      );
    }
    touch();
  }

  void completeOnboarding() {
    hasOnboarded = true;
    touch();
  }

  void addCustomSubject(String name, String code, List<String> paperNames) {
    subjects.add(
      Subject(
        id: _newId(),
        name: name,
        code: code,
        isCustom: true,
        papers: paperNames
            .map((n) => Paper(id: _newId(), name: n, isCustom: true))
            .toList(),
      ),
    );
    touch();
  }

  void removeSubject(Subject subject) {
    subjects.removeWhere((s) => s.id == subject.id);
    touch();
  }

  // ---- Papers ---------------------------------------------------------------

  void addCustomPaper(Subject subject, String name) {
    subject.papers.add(Paper(id: _newId(), name: name, isCustom: true));
    touch();
  }

  void removePaper(Subject subject, Paper paper) {
    subject.papers.removeWhere((p) => p.id == paper.id);
    touch();
  }

  void setExamDate(Paper paper, DateTime? date) {
    paper.examDate = date;
    touch();
  }

  void setAsDefault(Paper paper) {
    paper.setAsDefault();
    touch();
  }

  void resetToDefault(Paper paper) {
    paper.resetToDefault();
    touch();
  }

  void clearDefault(Paper paper) {
    paper.clearDefault();
    touch();
  }

  // ---- Objectives -------------------------------------------------------

  void addObjective(Paper paper, String text) {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;
    paper.objectives.add(Objective(id: _newId(), text: trimmed));
    touch();
  }

  void removeObjective(Paper paper, Objective obj) {
    paper.objectives.removeWhere((o) => o.id == obj.id);
    touch();
  }

  /// Re-inserts a previously removed objective — powers the "Undo" action
  /// on the delete snackbar.
  void restoreObjective(Paper paper, Objective obj, int index) {
    final i = index.clamp(0, paper.objectives.length);
    paper.objectives.insert(i, obj);
    touch();
  }

  void editObjectiveText(Paper paper, Objective obj, String newText) {
    final trimmed = newText.trim();
    if (trimmed.isEmpty) return;
    obj.text = trimmed;
    touch();
  }

  void toggleObjectiveDone(Paper paper, Objective obj) {
    obj.isDone = !obj.isDone;
    if (obj.isDone) {
      obj.deferredUntil = null;
      _registerActivityToday();
    }
    touch();
  }

  void deferObjective(Paper paper, Objective obj) {
    obj.deferToTomorrow();
    touch();
  }

  void bringBackToday(Paper paper, Objective obj) {
    obj.bringBackToday();
    touch();
  }

  void _registerActivityToday() {
    final today = dateOnly(DateTime.now());
    if (lastActiveDate == null) {
      streak = 1;
    } else {
      final diff = today.difference(dateOnly(lastActiveDate!)).inDays;
      if (diff == 0) {
        // already active today
      } else if (diff == 1) {
        streak += 1;
      } else {
        streak = 1;
      }
    }
    lastActiveDate = today;
  }

  // ---- Dashboard-level stats ----------------------------------------------

  int get totalObjectivesAll =>
      subjects.fold(0, (sum, s) => sum + s.totalObjectives);
  int get doneObjectivesAll =>
      subjects.fold(0, (sum, s) => sum + s.doneObjectives);
  double get overallCompletion =>
      totalObjectivesAll == 0 ? 0 : doneObjectivesAll / totalObjectivesAll;

  Paper? get nearestPaper {
    Paper? nearest;
    int? nearestDays;
    for (final s in subjects) {
      for (final p in s.papers) {
        final d = p.daysUntilExam;
        if (d != null && (nearestDays == null || d < nearestDays)) {
          nearestDays = d;
          nearest = p;
        }
      }
    }
    return nearest;
  }

  Subject? subjectOfPaper(Paper paper) {
    for (final s in subjects) {
      if (s.papers.any((p) => p.id == paper.id)) return s;
    }
    return null;
  }
}
