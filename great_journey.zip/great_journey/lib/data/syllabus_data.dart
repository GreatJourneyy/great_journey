/// Static catalog shown on the subject-selection screen. Selecting one
/// creates a real working [Subject] (see AppState.toggleSubjectSelection).
class SubjectTemplate {
  final String name;
  final String code;
  final List<String> paperNames;

  const SubjectTemplate({
    required this.name,
    required this.code,
    required this.paperNames,
  });
}

const List<SubjectTemplate> kAvailableSubjects = [
  SubjectTemplate(
    name: 'Business',
    code: '9609',
    paperNames: ['P12', 'P22', 'P32', 'P42'],
  ),
  SubjectTemplate(
    name: 'Computer Science',
    code: '9618',
    paperNames: ['P12', 'P22', 'P32', 'P42'],
  ),
  SubjectTemplate(
    name: 'Math',
    code: 'Edexcel',
    paperNames: ['Wma11/01', 'Wma12/01', 'Wma13/01', 'Wma14/01', 'M1'],
  ),
];
