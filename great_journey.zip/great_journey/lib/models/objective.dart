/// Strips the time component so day comparisons are always clean.
DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

/// A single checklist item inside one exam paper's checklist.
///
/// Lifecycle: an objective starts "today" (deferredUntil == null). Checking
/// it sets [isDone]. Tapping "→ Tomorrow" instead sets [deferredUntil] to
/// tomorrow's date, which moves it out of the Today list into the Deferred
/// list. The next time the app is opened on/after that date, [rollIfDue]
/// clears the flag automatically and it reappears in Today — that's the
/// "thrown to tomorrow" behaviour.
class Objective {
  final String id;
  String text;
  bool isDone;
  DateTime? deferredUntil;
  final DateTime createdAt;

  Objective({
    required this.id,
    required this.text,
    this.isDone = false,
    this.deferredUntil,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  bool get isDeferred => deferredUntil != null;

  /// If this objective was deferred to a date that has now arrived (or
  /// passed), clear the flag so it moves back into the active list.
  /// Returns true if a change was made.
  bool rollIfDue(DateTime today) {
    if (deferredUntil != null && !deferredUntil!.isAfter(dateOnly(today))) {
      deferredUntil = null;
      return true;
    }
    return false;
  }

  void deferToTomorrow() {
    final tomorrow = dateOnly(DateTime.now()).add(const Duration(days: 1));
    deferredUntil = tomorrow;
    isDone = false;
  }

  void bringBackToday() => deferredUntil = null;

  Objective copy() => Objective(
    id: id,
    text: text,
    isDone: isDone,
    deferredUntil: deferredUntil,
    createdAt: createdAt,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'text': text,
    'isDone': isDone,
    'deferredUntil': deferredUntil?.toIso8601String(),
    'createdAt': createdAt.toIso8601String(),
  };

  factory Objective.fromJson(Map<String, dynamic> json) => Objective(
    id: json['id'] as String,
    text: json['text'] as String,
    isDone: json['isDone'] as bool? ?? false,
    deferredUntil: json['deferredUntil'] == null
        ? null
        : DateTime.parse(json['deferredUntil'] as String),
    createdAt: json['createdAt'] == null
        ? DateTime.now()
        : DateTime.parse(json['createdAt'] as String),
  );
}
