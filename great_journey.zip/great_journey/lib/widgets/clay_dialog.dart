import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'clay_button.dart';

/// Single text-field prompt (used for "add objective", "rename",
/// "add custom paper", etc). Returns null if cancelled.
Future<String?> promptText(
  BuildContext context, {
  required String title,
  String hint = '',
  String confirmLabel = 'Save',
  String initialValue = '',
}) {
  final controller = TextEditingController(text: initialValue);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppColors.bgTop,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      title: Text(title, style: Theme.of(ctx).textTheme.headlineSmall),
      content: TextField(
        controller: controller,
        autofocus: true,
        maxLength: 120,
        decoration: InputDecoration(
          hintText: hint,
          filled: true,
          fillColor: AppColors.bgBottom,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
        onSubmitted: (v) => Navigator.of(ctx).pop(v),
      ),
      actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      actions: [
        ClayButton(
          label: 'Cancel',
          compact: true,
          color: AppColors.stoneGray,
          onPressed: () => Navigator.of(ctx).pop(),
        ),
        ClayButton(
          label: confirmLabel,
          compact: true,
          onPressed: () => Navigator.of(ctx).pop(controller.text),
        ),
      ],
    ),
  );
}

/// Yes/No confirmation for destructive or hard-to-reverse actions.
Future<bool> confirmAction(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Confirm',
  Color confirmColor = AppColors.glazeClay,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppColors.bgTop,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      title: Text(title, style: Theme.of(ctx).textTheme.headlineSmall),
      content: Text(message, style: Theme.of(ctx).textTheme.bodyLarge),
      actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      actions: [
        ClayButton(
          label: 'Cancel',
          compact: true,
          color: AppColors.stoneGray,
          onPressed: () => Navigator.of(ctx).pop(false),
        ),
        ClayButton(
          label: confirmLabel,
          compact: true,
          color: confirmColor,
          onPressed: () => Navigator.of(ctx).pop(true),
        ),
      ],
    ),
  );
  return result ?? false;
}
