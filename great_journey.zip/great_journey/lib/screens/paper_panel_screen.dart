import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/objective.dart';
import '../models/paper.dart';
import '../models/subject.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/clay_button.dart';
import '../widgets/clay_card.dart';
import '../widgets/clay_dialog.dart';
import '../widgets/empty_state.dart';
import '../widgets/objective_tile.dart';
import '../widgets/progress_ring.dart';

String formatDate(DateTime d) {
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  return '${d.day} ${months[d.month - 1]} ${d.year}';
}

class PaperPanelScreen extends StatefulWidget {
  final Subject subject;
  final Paper paper;
  const PaperPanelScreen({
    super.key,
    required this.subject,
    required this.paper,
  });

  @override
  State<PaperPanelScreen> createState() => _PaperPanelScreenState();
}

class _PaperPanelScreenState extends State<PaperPanelScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<AppState>().rollDueForPaper(widget.paper);
    });
  }

  Future<void> _pickDate(BuildContext context, AppState appState, Paper paper) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: paper.examDate ?? now.add(const Duration(days: 30)),
      firstDate: now.subtract(const Duration(days: 1)),
      lastDate: DateTime(now.year + 3),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: Theme.of(
            ctx,
          ).colorScheme.copyWith(primary: AppColors.glazeBlueDeep),
        ),
        child: child!,
      ),
    );
    if (picked != null) appState.setExamDate(paper, picked);
  }

  Future<void> _addObjective(BuildContext context, AppState appState, Paper paper) async {
    final text = await promptText(
      context,
      title: 'New objective',
      hint: 'e.g. Revise Chapter 4',
    );
    if (text != null && text.trim().isNotEmpty) {
      appState.addObjective(paper, text.trim());
    }
  }

  void _deleteWithUndo(
    BuildContext context,
    AppState appState,
    Paper paper,
    Objective obj,
  ) {
    final index = paper.objectives.indexOf(obj);
    appState.removeObjective(paper, obj);
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.ink,
        content: Text(
          'Deleted "${obj.text}"',
          style: const TextStyle(color: Colors.white),
        ),
        action: SnackBarAction(
          label: 'Undo',
          textColor: AppColors.glazeBlue,
          onPressed: () => appState.restoreObjective(paper, obj, index),
        ),
      ),
    );
  }

  ({String text, Color color}) _statusFor(Paper paper) {
    if (paper.totalCount == 0) {
      return (text: 'Add your first objective below.', color: AppColors.inkFaint);
    }
    if (paper.remainingCount == 0) {
      return (text: 'All done here! Great work.', color: AppColors.glazeSage);
    }
    final days = paper.daysUntilExam;
    if (days == null) {
      return (text: 'Set an exam date to see your daily pace.', color: AppColors.inkFaint);
    }
    if (days <= 0) {
      return (text: "Exam day is here — you've got this.", color: AppColors.glazeClay);
    }
    final pace = paper.pacePerDay ?? 0;
    if (pace <= 1) {
      return (text: 'Comfortable pace — about 1 a day.', color: AppColors.glazeSage);
    }
    if (pace <= 3) {
      return (
        text: 'Steady pace — about ${pace.ceil()} a day keeps you on track.',
        color: AppColors.glazeBlueDeep,
      );
    }
    return (
      text: 'About ${pace.ceil()} a day needed — worth picking up the pace.',
      color: AppColors.glazeClay,
    );
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final paper = widget.subject.papers.firstWhere(
      (p) => p.id == widget.paper.id,
      orElse: () => widget.paper,
    );
    final status = _statusFor(paper);
    final days = paper.daysUntilExam;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppTheme.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
                child: Row(
                  children: [
                    ClayIconButton(
                      icon: Icons.arrow_back_rounded,
                      size: 40,
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            paper.name,
                            style: Theme.of(context).textTheme.headlineMedium,
                          ),
                          Text(
                            widget.subject.title,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 30),
                  children: [
                    ClayCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              ProgressRing(
                                progress: paper.completionRatio,
                                size: 64,
                                strokeWidth: 8,
                                centerLabel: '${paper.doneCount}/${paper.totalCount}',
                              ),
                              const SizedBox(width: 18),
                              Expanded(
                                child: GestureDetector(
                                  onTap: () => _pickDate(context, appState, paper),
                                  child: Row(
                                    children: [
                                      const Icon(
                                        Icons.calendar_today,
                                        size: 18,
                                        color: AppColors.glazeBlueDeep,
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          days == null
                                              ? 'Tap to set exam date'
                                              : '${formatDate(paper.examDate!)} · ${days <= 0 ? 'today' : '$days day${days == 1 ? '' : 's'} left'}',
                                          style: Theme.of(context).textTheme.titleMedium,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: status.color.withValues(alpha: 0.18),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.bolt, size: 16, color: status.color),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    status.text,
                                    style: Theme.of(context).textTheme.bodyMedium
                                        ?.copyWith(color: AppColors.ink),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Today', style: Theme.of(context).textTheme.headlineSmall),
                        ClayButton(
                          label: 'Add',
                          icon: Icons.add_rounded,
                          compact: true,
                          onPressed: () => _addObjective(context, appState, paper),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (paper.totalCount == 0)
                      EmptyState(
                        icon: Icons.playlist_add_check,
                        title: 'Nothing here yet',
                        message:
                            'Add the topics or tasks you want to work through before this paper.',
                        actionLabel: 'Add objective',
                        onAction: () => _addObjective(context, appState, paper),
                      )
                    else if (paper.todayObjectives.isEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Text(
                          'Nothing left for today — check Deferred or Completed below.',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      )
                    else
                      for (final o in paper.todayObjectives)
                        ObjectiveTile(
                          key: ValueKey(o.id),
                          objective: o,
                          mode: ObjectiveTileMode.today,
                          onToggleDone: () => appState.toggleObjectiveDone(paper, o),
                          onDefer: () => appState.deferObjective(paper, o),
                          onDelete: () => _deleteWithUndo(context, appState, paper, o),
                          onEdit: (t) => appState.editObjectiveText(paper, o, t),
                        ),

                    if (paper.deferredObjectives.isNotEmpty) ...[
                      const SizedBox(height: 22),
                      _CollapsibleSection(
                        title: 'Deferred to tomorrow',
                        count: paper.deferredObjectives.length,
                        accent: AppColors.dustLilac,
                        children: [
                          for (final o in paper.deferredObjectives)
                            ObjectiveTile(
                              key: ValueKey(o.id),
                              objective: o,
                              mode: ObjectiveTileMode.deferred,
                              onToggleDone: () => appState.toggleObjectiveDone(paper, o),
                              onBringBackToday: () => appState.bringBackToday(paper, o),
                              onDelete: () => _deleteWithUndo(context, appState, paper, o),
                              onEdit: (t) => appState.editObjectiveText(paper, o, t),
                            ),
                        ],
                      ),
                    ],

                    if (paper.doneObjectives.isNotEmpty) ...[
                      const SizedBox(height: 22),
                      _CollapsibleSection(
                        title: 'Completed',
                        count: paper.doneObjectives.length,
                        accent: AppColors.glazeSage,
                        children: [
                          for (final o in paper.doneObjectives)
                            ObjectiveTile(
                              key: ValueKey(o.id),
                              objective: o,
                              mode: ObjectiveTileMode.done,
                              onToggleDone: () => appState.toggleObjectiveDone(paper, o),
                              onDelete: () => _deleteWithUndo(context, appState, paper, o),
                              onEdit: (t) => appState.editObjectiveText(paper, o, t),
                            ),
                        ],
                      ),
                    ],

                    const SizedBox(height: 30),
                    Text(
                      'Default checklist',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      paper.hasDefault
                          ? "Saved. Reset any time to wipe today's progress and start this list fresh."
                          : "Save your current checklist as the one you'll return to until the exam.",
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        ClayButton(
                          label: 'Set as Default',
                          icon: Icons.bookmark_border,
                          compact: true,
                          onPressed: paper.totalCount == 0
                              ? null
                              : () => appState.setAsDefault(paper),
                        ),
                        ClayButton(
                          label: 'Reset to Default',
                          icon: Icons.refresh,
                          compact: true,
                          color: AppColors.stoneGray,
                          onPressed: !paper.hasDefault
                              ? null
                              : () async {
                                  final confirmed = await confirmAction(
                                    context,
                                    title: 'Reset to default?',
                                    message:
                                        "This replaces today's list with your saved default and clears current progress.",
                                    confirmLabel: 'Reset',
                                  );
                                  if (confirmed) appState.resetToDefault(paper);
                                },
                        ),
                        if (paper.hasDefault)
                          ClayButton(
                            label: 'Clear Default',
                            icon: Icons.close_rounded,
                            compact: true,
                            color: AppColors.bgBottom,
                            onPressed: () async {
                              final confirmed = await confirmAction(
                                context,
                                title: 'Clear saved default?',
                                message: 'You can always save a new default later.',
                                confirmLabel: 'Clear',
                              );
                              if (confirmed) appState.clearDefault(paper);
                            },
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CollapsibleSection extends StatefulWidget {
  final String title;
  final int count;
  final Color accent;
  final List<Widget> children;
  const _CollapsibleSection({
    required this.title,
    required this.count,
    required this.accent,
    required this.children,
  });

  @override
  State<_CollapsibleSection> createState() => _CollapsibleSectionState();
}

class _CollapsibleSectionState extends State<_CollapsibleSection> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () => setState(() => _expanded = !_expanded),
          child: Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.accent,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                '${widget.title} (${widget.count})',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const Spacer(),
              AnimatedRotation(
                turns: _expanded ? 0.5 : 0,
                duration: const Duration(milliseconds: 180),
                child: const Icon(Icons.expand_more, color: AppColors.inkFaint),
              ),
            ],
          ),
        ),
        AnimatedCrossFade(
          firstChild: const SizedBox(width: double.infinity),
          secondChild: Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Column(children: widget.children),
          ),
          crossFadeState: _expanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
          duration: const Duration(milliseconds: 200),
        ),
      ],
    );
  }
}
