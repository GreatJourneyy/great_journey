import 'package:flutter/material.dart';
import '../models/objective.dart';
import '../theme/app_theme.dart';
import 'clay_button.dart';
import 'clay_checkbox.dart';
import 'clay_dialog.dart';

enum ObjectiveTileMode { today, deferred, done }

/// One checklist row. Swipe left to delete (with undo, handled by the
/// caller's onDelete), long-press to rename, tap the ring to complete.
class ObjectiveTile extends StatelessWidget {
  final Objective objective;
  final ObjectiveTileMode mode;
  final VoidCallback onToggleDone;
  final VoidCallback? onDefer;
  final VoidCallback? onBringBackToday;
  final VoidCallback onDelete;
  final ValueChanged<String> onEdit;

  const ObjectiveTile({
    super.key,
    required this.objective,
    required this.mode,
    required this.onToggleDone,
    required this.onDelete,
    required this.onEdit,
    this.onDefer,
    this.onBringBackToday,
  });

  Future<void> _edit(BuildContext context) async {
    final result = await promptText(
      context,
      title: 'Edit objective',
      initialValue: objective.text,
    );
    if (result != null && result.trim().isNotEmpty) {
      onEdit(result.trim());
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget? trailing;
    if (mode == ObjectiveTileMode.today && onDefer != null) {
      trailing = Tooltip(
        message: 'Push to tomorrow',
        child: ClayIconButton(
          icon: Icons.arrow_forward_rounded,
          size: 34,
          onPressed: onDefer,
        ),
      );
    } else if (mode == ObjectiveTileMode.deferred &&
        onBringBackToday != null) {
      trailing = Tooltip(
        message: 'Bring back to today',
        child: ClayIconButton(
          icon: Icons.undo,
          size: 34,
          onPressed: onBringBackToday,
        ),
      );
    }

    return Dismissible(
      key: ValueKey(objective.id),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDelete(),
      background: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 22),
        alignment: Alignment.centerRight,
        decoration: BoxDecoration(
          color: AppColors.glazeClay,
          borderRadius: BorderRadius.circular(AppRadii.cardSmall),
        ),
        child: const Icon(Icons.delete_outline, color: Colors.white),
      ),
      child: GestureDetector(
        onLongPress: () => _edit(context),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.bgTop,
            borderRadius: BorderRadius.circular(AppRadii.cardSmall),
            boxShadow: AppTheme.raisedSmall(),
          ),
          child: Row(
            children: [
              ClayCheckbox(
                value: objective.isDone,
                onChanged: onToggleDone,
                size: 26,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  objective.text,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: objective.isDone
                        ? AppColors.inkFaint
                        : AppColors.ink,
                    decoration: objective.isDone
                        ? TextDecoration.lineThrough
                        : TextDecoration.none,
                  ),
                ),
              ),
              if (trailing != null) ...[const SizedBox(width: 8), trailing],
            ],
          ),
        ),
      ),
    );
  }
}
